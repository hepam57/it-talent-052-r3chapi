function fun(){
var n1=

alert('click' +document.getElementById('miInput').value);

}

function funcioHtml(){
  document.getElementById('response').innerText= document.getElementById('n1').value

}
function sumar(){
  var n1= parseInt(document.getElementById('n1').value)
  var n2= parseInt(document.getElementById('n2').value)
  var r=n1+n2
  document.getElementById('response').innerText= r
}
function restar(){
  var n1=document.getElementById('n1').value
  var n2=document.getElementById('n2').value
  var r=n1-n2
  document.getElementById('response').innerText= r
}
function multiplicar(){
  var n1=document.getElementById('n1').value
  var n2=document.getElementById('n2').value
  var r=n1*n2
  document.getElementById('response').innerText= r
}
function dividir(){
  var n1=document.getElementById('n1').value
  var n2=document.getElementById('n2').value
  if (n2!=0) 
    {
       var r=n1/n2
    } 
    else {
       var r="Divisiòn no permitida"
    } 
    
  document.getElementById('response').innerText= r
}


//imprimir(y,1);
//imprimir(y,2);
//imprimir(y,3);
//imprimir(y,4);
//imprimir(y,5);
//imprimir(y,6);
//imprimir(y,7);
//imprimir(y,8);
//imprimir(y,9);
//Vverdad = true;
//VFalsa = false;
//alert(Vverdad && VFalsa);
//alert(Vverdad && Vverdad);
//alert(VFalsa && VFalsa);
//alert(VFalsa && Vverdad);


//alert('resultado o' + Vverdad || VFalsa);
//alert('resultado o' + Vverdad || Vverdad);
//alert('resultado o' + VFalsa || VFalsa);
//alert('resultado o' + VFalsa || Vverdad);

//var c = (5==3)
  //alert(c)

//var n1 =prompt("Ingrese un numero");
//var n2 =prompt("Ingrese un numero2");
//var suma =parseInt(n1) + parseInt(n2);
//  alert(suma);
